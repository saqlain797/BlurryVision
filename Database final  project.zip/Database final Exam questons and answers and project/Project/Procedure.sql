
/*Procedure 1*/
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `in`()
BEGIN
	select * from employee;
END$$
DELIMITER ;
/*Procedure 2*/
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `out`(in id int)
BEGIN
	select * from employee where e_id = id;
END$$
DELIMITER ;
/*Procedure 3*/
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `in_out`(in name varchar(20))
BEGIN
	select * from hospital where h_name = name;
END$$
DELIMITER ;